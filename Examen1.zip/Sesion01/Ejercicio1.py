# -*- coding: utf-8 -*-
"""
Created on Mon Jan 20 15:57:16 2025

@author: uo299673
"""

import numpy as np
import matplotlib as mt
a= np.array([1,3,7])
b= np.array([(2,4,3),(0,1,6)])
c=np.array([1,1,1])
d= np.array([0,0,0,0])
e=np.array([(0,0),(0,0),(0,0)])
f= np.array([(1,1,1,1),(1,1,1,1),(1,1,1,1)])
print("a:")
print(a)
print("b:")
print(b)
print("c:")
print(c)
print("d:")
print(d)
print("e:")
print(e)
print("f:")
print(f)
