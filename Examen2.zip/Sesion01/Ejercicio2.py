# -*- coding: utf-8 -*-
"""
Created on Mon Jan 20 16:02:20 2025

@author: uo299673
"""

import numpy as np
import matplotlib as mt
np.set_printoptions(precision=1,suppress=True)#usar para que no se usen ni exponentes ni (precision) dígitos
print("A")
print("Arange:")
aR=np.arange(7,17,2)
print(aR)
print("Linspace:")
aL=np.linspace(7, 15, 5)
print(aL)


print("B")
print("Arange:")
bR=np.arange(10,5,-1)
print(bR)
print("Linspace:")
bL=np.linspace(10, 6, 5)
print(bL)


print("C")
print("Arange:")
cR=np.arange(15,-1,-5)
print(cR)
print("Linspace:")
cL=np.linspace(15, 0, 4)
print(cL)


print("D")
print("Arange:")
dR=np.arange(0., 1.1,0.1)
print(dR)
print("Linspace:")
dL=np.linspace(0., 1, 11)
print(dL)


print("E")
print("Arange:")
eR=np.arange(-1, 1.2,0.2)
print(eR)
print("Linspace:")
eL=np.linspace(-1, 1, 10)
print(eL)


print("F")
print("Arange:")
fR=np.arange(1, 2.1,0.1)
print(fR)
print("Linspace:")
fL=np.linspace(1, 2, 10)
print(fL)